USE DB_project;
GO

DROP TRIGGER IF EXISTS Education.trg_Validate_NationalCode_Instructors;

CREATE OR ALTER TRIGGER trg_Validate_NationalCode_Instructors
ON Education.Instructors
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 
        FROM inserted AS InsertedInstructorData
        WHERE Education.fn_IsValidNationalCode(InsertedInstructorData.NationalIdentityCode) = 0
    )
    BEGIN
        RAISERROR(N'The provided national code for the instructor is invalid.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    INSERT INTO Education.Instructors (
        NationalIdentityCode, PrimaryFirstName, PrimaryLastName, FatherFullName, DateOfBirth, GenderCode,
        ContactPhoneNumber, InstitutionalEmail, EmploymentDate, AssignedDepartmentID, AcademicRank, EmploymentStatus
    )
    SELECT
        NationalIdentityCode, PrimaryFirstName, PrimaryLastName, FatherFullName, DateOfBirth, GenderCode,
        ContactPhoneNumber, InstitutionalEmail, EmploymentDate, AssignedDepartmentID, AcademicRank, EmploymentStatus
    FROM inserted;
END;
GO