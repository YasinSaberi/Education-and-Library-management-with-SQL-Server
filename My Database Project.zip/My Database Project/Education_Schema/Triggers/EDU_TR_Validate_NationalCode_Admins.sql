USE DB_project;
GO

DROP TRIGGER IF EXISTS Education.trg_Validate_NationalCode_Admins;

CREATE OR ALTER TRIGGER trg_Validate_NationalCode_Admins
ON Education.Admins
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 
        FROM inserted AS InsertedAdminData
        WHERE Education.fn_IsValidNationalCode(InsertedAdminData.NationalIdentifier) = 0
    )
    BEGIN
        RAISERROR(N'The provided national code for the administrator is invalid.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    INSERT INTO Education.Admins (
        NationalIdentifier, GivenName, FamilyName, UserRole, ContactNumber, EmailAddress
    )
    SELECT
        NationalIdentifier, GivenName, FamilyName, UserRole, ContactNumber, EmailAddress
    FROM inserted;
END;
GO