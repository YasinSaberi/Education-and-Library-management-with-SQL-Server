USE DB_project;
GO

DROP TRIGGER IF EXISTS Education.trg_Validate_NationalCode_Students;
GO

CREATE OR ALTER TRIGGER trg_Validate_NationalCode_Students
ON Education.Students
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (
        SELECT 1 
        FROM inserted AS InsertedStudentData
        WHERE Education.fn_IsValidNationalCode(InsertedStudentData.NationalIdentityNumber) = 0
    )
    BEGIN
        RAISERROR(N'The provided national code for the student is invalid.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END;

    INSERT INTO Education.Students (
        NationalIdentityNumber, StudentFirstName, StudentLastName, StudentFatherName, DateOfBirth, GenderCode,
        ContactPhoneNumber, StudentEmailAddress, AcademicEntryYear, EnrolledDepartmentID, ChosenMajorID, EnrollmentStatus
    )
    SELECT
        NationalIdentityNumber, StudentFirstName, StudentLastName, StudentFatherName, DateOfBirth, GenderCode,
        ContactPhoneNumber, StudentEmailAddress, AcademicEntryYear, EnrolledDepartmentID, ChosenMajorID, EnrollmentStatus
    FROM inserted;
END;
GO