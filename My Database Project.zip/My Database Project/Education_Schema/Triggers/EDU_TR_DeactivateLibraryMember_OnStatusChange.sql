USE DB_project;
GO

DROP TRIGGER IF EXISTS Education.trg_DeactivateLibraryMember_OnStatusChange;

CREATE TRIGGER trg_DeactivateLibraryMember_OnStatusChange
ON Education.Students
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE library_member_profile
    SET library_member_profile.IsMemberAccountActive = 0
    FROM Library.Members AS library_member_profile
    INNER JOIN inserted AS updated_student_info 
        ON library_member_profile.AssociatedStudentID = updated_student_info.UniversityStudentID
    INNER JOIN deleted AS previous_student_info 
        ON updated_student_profile.UniversityStudentID = previous_student_info.UniversityStudentID
    WHERE 
        updated_student_info.EnrollmentStatus IN (N'Expelled', N'Graduated', N'Dropped') 
        AND previous_student_info.EnrollmentStatus = N'Active';    
END;