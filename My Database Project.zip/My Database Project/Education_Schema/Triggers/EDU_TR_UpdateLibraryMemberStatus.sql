USE DB_project;
GO

DROP TRIGGER IF EXISTS Education.trg_UpdateMemberIsActive;
GO

CREATE OR ALTER TRIGGER trg_UpdateMemberIsActive
ON Education.Students
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE LibraryAccount
    SET LibraryAccount.IsActive = 0
    FROM 
        Library.Members AS LibraryAccount
    INNER JOIN 
        inserted AS UpdatedStudentRecord 
        ON LibraryAccount.UniversityStudentID = UpdatedStudentRecord.UniversityStudentID
    INNER JOIN 
        deleted AS OriginalStudentState 
        ON UpdatedStudentRecord.UniversityStudentID = OriginalStudentState.UniversityStudentID
    WHERE 
        OriginalStudentState.EnrollmentStatus = 'Active' 
        AND UpdatedStudentRecord.EnrollmentStatus <> 'Active';
END;